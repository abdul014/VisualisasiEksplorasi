library(shiny)
library(ggplot2)
library(dplyr)
library(randomForest)
library(caret)

# Load Data
data_url <- "https://raw.githubusercontent.com/abdul014/VisualisasiEksplorasi/refs/heads/main/data.csv"
data <- read.csv(data_url)

# Transformasi Data
data <- data %>%
  mutate(
    Sex = ifelse(Sex == 1, "Male", "Female"),
    Class = factor(Class, labels = c("Underweight", "Normal", "Overweight", "Obese"))
  )

# UI
ui <- fluidPage(
  tags$head(
    tags$link(rel = "stylesheet", type = "text/css", href = "style.css")  # Custom CSS
  ),
  titlePanel("Random Forest Experiment Dashboard"),
  sidebarLayout(
    sidebarPanel(
      radioButtons(
        inputId = "menu",
        label = "Pilih Menu",
        choices = list(
          "Beranda" = "home",
          "Analisis Data" = "analysis",
          "Random Forest Experiment" = "randomforest"
        ),
        selected = "home"
      ),
      hr(),
      div("© 2024 Dashboard by Kelompok 8", class = "footer")
    ),
    mainPanel(
      uiOutput("main_content")
    )
  )
)

# Server
server <- function(input, output, session) {
  experiment_started <- reactiveVal(FALSE)
  train_clicked <- reactiveVal(FALSE)  # Default FALSE untuk menyembunyikan output
  
  # Menu Logic
  output$main_content <- renderUI({
    if (input$menu == "home") {
      tagList(
        h3("Selamat Datang di Dashboard Analisis Obesity"),
        p("Gunakan menu di sebelah kiri untuk mengeksplorasi data dan analisis."),
        p("Dashboard ini dirancang untuk membantu Anda memahami data obesity.")
      )
    } else if (input$menu == "analysis") {
      tagList(
        h3("Analisis Data"),
        plotOutput("obesity_plot")
      )
    } else if (input$menu == "randomforest") {
      tagList(
        div(
          class = "title-container",
          HTML("<h1><span style='color: black;'>Random Forest</span> 
                <span style='color: green;'>Experiment</span> ☕ ☕</h1>")
        ),
        p("Gunakan pengaturan di bawah ini untuk mencoba model Random Forest. Pilih parameter, klik 'Train', dan hasil metrik model akan ditampilkan setelah selesai."),
        if (!experiment_started()) {
          actionButton("start_experiment", "Mulai Eksperimen", class = "btn-primary")
        } else {
          tagList(
            fluidRow(
              column(
                width = 6,
                div(
                  class = "slider-container",
                  h4("No of Estimators"),
                  sliderInput("n_estimators", "", min = 100, max = 1000, value = 280, step = 10)
                ),
                div(
                  class = "slider-container",
                  h4("Max Depth"),
                  sliderInput("max_depth", "", min = 2, max = 20, value = 7, step = 1)
                ),
                selectInput("max_features", "Max Features:", choices = c("auto", "sqrt", "log2"), selected = "auto"),
                checkboxInput("bootstrap", "Bootstrap", value = TRUE),
                checkboxInput("save_model", "Save Model", value = FALSE),
                actionButton("train", "Train", class = "btn-primary")
              ),
              column(
                width = 6,
                div(
                  class = "results-container",  # Wrapper untuk hasil lainnya
                  conditionalPanel(
                    condition = "output.showResults",
                    h4("Test Accuracy:"),
                    verbatimTextOutput("test_accuracy"),
                    h4("Train Accuracy:"),
                    verbatimTextOutput("train_accuracy"),
                    h4("Confusion Matrix:"),
                    plotOutput("confusion_matrix")
                  )
                )
              )
            ),
            fluidRow(
              column(
                width = 12,  # Gunakan seluruh lebar area untuk tabel
                div(
                  class = "classification-container",
                  conditionalPanel(
                    condition = "output.showResults",
                    h4("Classification Report:"),
                    tableOutput("classification_report")
                  )
                )
              )
            )
          )
        }
      )
    } else {
      h3("Menu tidak ditemukan")
    }
  })
  
  # Logic for Start Experiment Button
  observeEvent(input$start_experiment, {
    experiment_started(TRUE)
  })
  
  # Logic for Train Button
  observeEvent(input$train, {
    train_clicked(TRUE)  # Ubah ke TRUE ketika Train diklik
    
    # Split data
    set.seed(123)
    train_index <- createDataPartition(data$Class, p = 0.7, list = FALSE)
    train_data <- data[train_index, ]
    test_data <- data[-train_index, ]
    
    # Determine max features
    max_features <- switch(
      input$max_features,
      "auto" = ncol(train_data) - 1,
      "sqrt" = sqrt(ncol(train_data) - 1),
      "log2" = log2(ncol(train_data) - 1)
    )
    
    # Train the model
    rf_model <- randomForest(
      Class ~ ., 
      data = train_data,
      ntree = input$n_estimators,
      mtry = max_features,
      maxnodes = input$max_depth,
      importance = TRUE
    )
    
    # Predictions and accuracy
    train_predictions <- predict(rf_model, train_data)
    test_predictions <- predict(rf_model, test_data)
    
    train_confusion <- confusionMatrix(train_predictions, train_data$Class)
    test_confusion <- confusionMatrix(test_predictions, test_data$Class)
    
    train_accuracy <- train_confusion$overall['Accuracy']
    test_accuracy <- test_confusion$overall['Accuracy']
    
    # Classification report
    classification_report <- as.data.frame(test_confusion$byClass)
    
    # Render outputs
    output$train_accuracy <- renderText({
      paste(round(train_accuracy * 100, 2), "%")
    })
    output$test_accuracy <- renderText({
      paste(round(test_accuracy * 100, 2), "%")
    })
    output$confusion_matrix <- renderPlot({
      confusion_table <- as.data.frame(test_confusion$table)
      ggplot(confusion_table, aes(Reference, Prediction)) +
        geom_tile(aes(fill = Freq), color = "white") +
        geom_text(aes(label = Freq)) +
        scale_fill_gradient(low = "#ffffff", high = "#4CAF50") +
        labs(title = "Confusion Matrix", x = "Reference", y = "Prediction") +
        theme_minimal()
    })
    output$classification_report <- renderTable({
      classification_report
    }, rownames = TRUE)
  })
  
  # Conditional panel output logic
  output$showResults <- reactive({
    train_clicked()  # Tampilkan hasil hanya jika Train diklik
  })
  outputOptions(output, "showResults", suspendWhenHidden = FALSE)
}

# Run App
shinyApp(ui, server)
